CREATE table aluno (
  id_aluno serial,
  nome VARCHAR (20),
  curso VARCHAR (50),
  PRIMARY key (id_aluno)
  )
  
  INSERT into aluno (nome, curso)
  values ('Beatriz','Banco de Dados'),
  ('Palú','Pedagogia'),
  ('Isadora','Administração'),
  ('Vishnu','ciência da computação')
  
  create table nota (
    id_nota serial,
    aluno_id  serial,
    nota decimal (3,1),
    PRIMARY key (id_nota),
    FOREIGN key (aluno_id)
    REFERENCES aluno (id_aluno)
    )
    
    insert into nota (nota)
    VALUES (8.5),
    (9.3),
    (9.0),
    (8.7)
    
    select avg (N.nota), A.nome , A.curso from aluno A RIGHT join nota N on A.id_aluno = N.aluno_id