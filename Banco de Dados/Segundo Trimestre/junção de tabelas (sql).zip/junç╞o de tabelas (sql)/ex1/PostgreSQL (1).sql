create table cliente (
  id_cliente serial,
  nome VARCHAR (20),
  PRIMARY key (id_cliente)
  )
  
  insert into cliente (nome)
  values ('Beatriz'),
  ('Isadora'),
  ('Palú'),
  ('Vishnu')
  
  create table email_cliente (
    email VARCHAR (30),
    PRIMARY key (email)
    )
    
create table pedido (
  id_pedido serial,
  cliente_id serial,
  valor DECIMAL (7,2),
  primary key (id_pedido),
  FOREIGN key (cliente_id)
  REFERENCES cliente (id_cliente)
  )
  
  insert into pedido (valor)
  values (200.50),
  (348.45),
  (1180.00),
  (23.90)
 
  SELECT cliente.nome, pedido.valor from cliente RIGHT JOIN pedido on cliente.id_cliente = pedido.cliente_id
 