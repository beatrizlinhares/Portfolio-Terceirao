
function listaT (nome){
    switch (nome){
        case 'Beatriz':
            console.log('Beatriz = (48)98480-0009')
            break
        case 'Ana':
            console.log('Ana = (48)99953-9093')
            break
        case 'Isadora Palú':
            console.log('Palú = (48)99916-2630')
            break
        case 'Vishnu':
            console.log('Vishnu = (48)93300-3927')
            break
        case 'Isadora Velho':
            console.log('Isadora = (48)98429-3518')
            break  
    }
}

listaT('Beatriz')