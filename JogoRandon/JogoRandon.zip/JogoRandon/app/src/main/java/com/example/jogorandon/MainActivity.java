package com.example.jogorandon;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText entrada; //inicializando
    TextView resultado;
    int numeroGerado = 0;
    int tentativas = 0;
    Random gerador = new Random(); //gerar numero aleatorio

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        entrada = findViewById(R.id.entrada);
        resultado = findViewById(R.id.resultado);
    }

    public void gerarNumero(View v) {
        tentativas = 0;
        numeroGerado = gerador.nextInt(100) + 1; //gerar numero de 0 á 99 + 1
    }

    public void confirmar(View v) {
        String mensagem = "";
        if (entrada.getText().toString().isEmpty()) {
            mensagem = "Digite um número";
        } else {
            tentativas++;

            int numero = Integer.parseInt(entrada.getText().toString()); //vinculando xml com java

            if (tentativas < 5) {
                if (numero > numeroGerado) { //se o numero for maior que o gerado
                    mensagem = "O número é menor!\nVocê tem mais " + (5 - tentativas) + " tentativas";
                } else if (numero < numeroGerado) {
                    mensagem = "O número é maior!\nVocê tem mais" + (5 - tentativas) + " tentativas";
                } else {
                    mensagem = "Parabéns! Você acertou!";
                }
            } else {
                mensagem = "Suas tentativas acabaram!";
            }

        }
        resultado.setText(mensagem);
    }
}