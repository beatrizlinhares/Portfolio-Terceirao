//segundo maior número dentro de um array

function SegMaior(array) {
    var CresArray = array.sort(); //.sort = array crescente
    return CresArray[1]; // segunda posição
  }

  console.log(SegMaior([2,4,5]))

