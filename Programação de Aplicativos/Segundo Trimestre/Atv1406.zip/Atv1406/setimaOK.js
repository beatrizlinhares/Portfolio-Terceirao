// retornar somente os números recebidos em um array com vários tipos de variáveis

function filtro(array) {
    const numeros = array.filter(elemento => typeof elemento === 'number'); //.filter = filtrar elementos
    return numeros;
  }

  console.log(filtro(["oi",2,false,5]))