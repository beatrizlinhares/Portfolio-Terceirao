// multiplicar sem *


// não entendi, na minha cabeça, como o resultado é 0, vai ser 0 + a, que var dar 2. Não faz sentido pra mim (explique-me pleasee)

function multiplicacao(a, b) {
    let resultado = 0;
    for (let i = 0; i < b; i++) {
      resultado += a;
    }
    
    return resultado;
  }
  
  console.log(multiplicacao(2,4))