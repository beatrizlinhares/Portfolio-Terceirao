// inverso do boolean ou inverso do número

function inverso (entrada){
    var tipo = typeof entrada
    if(tipo === "boolean"){
        return console.log(!entrada)
    }
    else if(tipo === "number"){
        return console.log(-entrada)
    }
    else {
        return console.log("Booelano ou Número esperados, mas o parâmetro é do tipo "+typeof entrada)
    }
}

inverso(12)