//somar números do array

let entrada = []
function somaA (entrada){
    var soma = 0
    for(var num of entrada){
        soma = Number (soma+num)
    }
    return soma
}
console.log(somaA([5,5,4]))
