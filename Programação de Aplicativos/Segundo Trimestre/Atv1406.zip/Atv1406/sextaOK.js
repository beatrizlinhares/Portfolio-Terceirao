// repetir o primeiro parametro quantas vezes for o segundo

//Fiz assim, repetiu mas não ficou em array, daí fui pesquisar
function repetir (p,n1){
return p.repeat(n1)
}

//Encontrei isso
function repete (palavra, n2) {
    const array = Array(n2).fill(palavra); // fill é um método pra preencher, então eu acredito que nesse caso está usando pra preencher com a palavra n2 vezes
    return array;
}

console.log(repete("oi",2))