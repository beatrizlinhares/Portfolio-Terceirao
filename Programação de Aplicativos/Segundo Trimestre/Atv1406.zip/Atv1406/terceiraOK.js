// mês correspondente ao número

function mes (numero){
switch (numero){ // escutando 
    case 1: // se for
        console.log('Janeiro') // retorna isso
        break //encerrar
    case 2: // se for 
        console.log('Fevereiro') // retorna isso
        break // encerrar
    case 3: // se for 
        console.log('Março') // retorna isso
        break // encerrar
    case 4: // se for sala
        console.log('Abril') // retorna isso
        break // encerrar
    case 5: // se for sala
        console.log('Maio') // retorna isso
        break // encerrar
    case 6: // se for sala
        console.log('Junho') // retorna isso
        break // encerrar
    case 7: // se for sala
        console.log('Julho') // retorna isso
        break // encerrar
    case 8: // se for sala
        console.log('Agosto') // retorna isso
        break // encerrar
    case 9: // se for sala
        console.log('Setembro') // retorna isso
        break // encerrar
    case 10: // se for sala
        console.log('Outubro') // retorna isso
        break // encerrar
    case 11: // se for sala
        console.log('Novembro') // retorna isso
        break // encerrar
    case 12: // se for sala
        console.log('Dezembro') // retorna isso
        break // encerrar
    default: // se não atender a nenhum requisito
        console.log('Não existe um mês com esse número') // retorna isso
        break // encerrar
}
}

mes(4)