// verificar se o primeiro número é maior que o segundo

function verifica (n1,n2){
    if (n1<n2){
        return console.log(n1+" é menor que "+n2)
    }
    else if (n1>n2){
        return console.log(n1+" é maior que "+n2)
    }
    else{
        return console.log(n1+" é igual a "+n2)
    }
}

verifica(1,6)