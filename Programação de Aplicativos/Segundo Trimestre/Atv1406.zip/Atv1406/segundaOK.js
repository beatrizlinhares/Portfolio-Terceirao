// receber a idade da pessoa e retornar os dias de vida q ela tem

function diasVida (idade){
    return dias = idade*365
}

console.log(diasVida(10)+ " dias.")