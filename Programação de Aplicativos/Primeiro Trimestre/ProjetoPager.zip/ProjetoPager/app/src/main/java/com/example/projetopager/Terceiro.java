package com.example.projetopager;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Terceiro#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Terceiro extends Fragment {

    ImageView foto;
    Button b1, b2;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Terceiro() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Terceiro.
     */
    // TODO: Rename and change types and number of parameters
    public static Terceiro newInstance(String param1, String param2) {
        Terceiro fragment = new Terceiro();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {//se quando checar permissão for diferente de PERMISSÃO GARANTIDA, pedir permissão de camera ou do armazenamento externo
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, 0); //solicite permissão
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_terceiro, container, false);
        b1 = v.findViewById(R.id.b1);
        b2 = v.findViewById(R.id.b2);
        foto = v.findViewById(R.id.iv); // relacionando componente xml com atributo java

        b1.setOnClickListener(click -> {
            tirarFoto();
        });

        b2.setOnClickListener(click -> {
            pegarFoto();
        });

        return v;
    }
    public void tirarFoto (){
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); //ir pra tela da camera
        abrirCamera.launch(i);
    }

    public void pegarFoto () {
        Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);//Action pick = escolher imagem e pegando imagem (intenção)
        abrirGaleria.launch(i);
    }

    ActivityResultLauncher<Intent> abrirCamera = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {//lançar resultado da intent (abrir camera) no result
        if (result.getResultCode() == Activity.RESULT_OK) { //se o result for ok
            Intent data = result.getData(); //pegar dado com a foto
            Bundle dado = data.getExtras(); //converter pra bitmap (tipo de imagem)
            Bitmap imagem = (Bitmap) dado.get("data"); //formato de imagem
            foto.setImageBitmap(imagem); //mudar imagem pra bitmap e colocar no imageView
        }
    });
    ActivityResultLauncher<Intent> abrirGaleria = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),result -> {//lançar resultado da intent (abrir camera) no result
        if (result.getResultCode() == Activity.RESULT_OK) { //se o result for ok
            Intent data = result.getData(); //pegar dado com a foto
            Uri imagemSelecionada = data.getData(); //fazendo um link pra imagem, o que é
            //uri é um endereço digital (www)
            String[] caminho = {MediaStore.Images.Media.DATA}; //caminho da imagem, onde está
            Cursor c = getActivity().getContentResolver().query(imagemSelecionada, caminho, null, null, null); //ir até a imagem
            c.moveToFirst(); //mover pra primeira coluna do banco de dados
            int coluna = c.getColumnIndex(caminho[0]); //sabe o valor da coluna
            String caminhoFisico = c.getString(coluna); //transformando pra string
            c.close();
            Bitmap imagem = (BitmapFactory.decodeFile(caminhoFisico)); //transformar caminho e imagem real
            // passos : endereço da memória, apontar pro endereço e transformar em imagem real
            foto.setImageBitmap(imagem); //mudar imagem pra bitmap e colocar no imageView
        }
    });
}